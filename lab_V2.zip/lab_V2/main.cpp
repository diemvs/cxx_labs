#include <iostream>
#include <math.h>
#include "XY.h"

int main() {
  double x, y;
  V2 v1;
  V2 v2;
  cin >> v1;
  cout << v1;
  cin >> v2;
  cout << v2;
  Cos(v1, v2);

  v1+v2;
  cout << v1;
}