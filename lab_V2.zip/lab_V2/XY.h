#pragma once

#include <iostream>
#include <math.h>
using namespace std;

class V2
{
  private:
    double v[2];
    friend ostream& operator<< (ostream &print, V2 &vector){
    	print << '(' << vector.v[0] << ", " << vector.v[1] << ')'<< endl;
    	return print;
    }
    friend istream& operator>> (istream &print, V2 &vector){
      cout << "Введите x" << endl;
      print >> vector.v[0];
      cout << "Введите y" << endl;
      print >> vector.v[1];
      return print;
    }
    friend void Cos(V2 &vector1, V2 &vector2){ //косинус угла между векторами
      double ch, zn;
      ch = vector1.v[0]*vector2.v[0]+vector1.v[1]*vector2.v[1];
      zn = sqrt(vector1.v[0]*vector1.v[0]+vector1.v[1]*vector1.v[1])*sqrt(vector2.v[0]*vector2.v[0]+vector2.v[1]*vector2.v[1]);
      cout <<"Cos = "<< (ch/zn) << endl;
    }
  public:
    V2(){
      v[0]=0; 
      v[1]=0;
      }
    V2(double x, double y) {
      v[0]=x; 
      v[1]=y;
      }
    ~V2(){
      
    }
    V2& operator= (const V2 &vector){
      this->v[0]=vector.v[0];
      this->v[1]=vector.v[1];
      return *this;
    }
    V2& operator+ (V2 &vector){
      this->v[0]=this->v[0]+vector.v[0];
      this->v[1]=this->v[1]+vector.v[1];
      return vector;
    }
    V2& operator* (double const C){ //Умножение на число
      this->v[0]=this->v[0]*C;
      this->v[1]=this->v[1]*C;
      return *this;
    }
};